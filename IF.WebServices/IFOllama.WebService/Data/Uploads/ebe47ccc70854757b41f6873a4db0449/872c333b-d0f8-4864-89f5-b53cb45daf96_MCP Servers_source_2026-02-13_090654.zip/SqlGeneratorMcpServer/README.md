﻿# SQL Generator MCP Server
.NET 9.0 SQL generation and translation
