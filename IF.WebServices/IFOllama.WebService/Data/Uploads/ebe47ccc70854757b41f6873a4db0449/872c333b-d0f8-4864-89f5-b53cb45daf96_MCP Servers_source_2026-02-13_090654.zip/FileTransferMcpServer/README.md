﻿# File Transfer MCP Server
.NET 9.0 - Upload/Download & Zip operations
