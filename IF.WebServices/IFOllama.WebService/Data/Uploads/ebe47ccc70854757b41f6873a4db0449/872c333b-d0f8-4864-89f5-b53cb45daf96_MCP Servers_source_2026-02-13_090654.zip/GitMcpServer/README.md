﻿# Git MCP Server
.NET 9.0 Git operations via LibGit2Sharp
