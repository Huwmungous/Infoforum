﻿# FileSystem MCP Server

A Model Context Protocol (MCP) server for file system operations.

## Quick Start

```bash
dotnet build
dotnet run
```

## Test

```bash
echo '{"jsonrpc":"2.0","id":1,"method":"initialize"}' | dotnet run
```
