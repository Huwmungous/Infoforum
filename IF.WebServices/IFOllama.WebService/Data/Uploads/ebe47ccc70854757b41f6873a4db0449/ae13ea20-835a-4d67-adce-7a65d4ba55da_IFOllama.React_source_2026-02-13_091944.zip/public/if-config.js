// Runtime configuration for deployed environments
// This file can be modified at deployment time without rebuilding
// Values here are available via window.IF_CONFIG
window.IF_CONFIG = {
  // Override config service URL if needed
  // configServiceUrl: 'https://longmanrd.net/config',
};
