export const environment = {
    production: false,
    apiUrl: 'http://localhost:5008/IFOllama', 
    // apiUrl: 'https://longmanrd.net/aiapi', 
    consoleLog: true,
    appName: '',
    realm: 'LongmanRd', 
    clientId: '53FF08FC-C03E-4F1D-A7E9-41F2CB3EE3C7'
  };